function openbtn() {
    document.getElementById('dropdown').style.height = "60%";
    
}


function closebtn() {
    document.getElementById('dropdown').style.height = "0";
    
}